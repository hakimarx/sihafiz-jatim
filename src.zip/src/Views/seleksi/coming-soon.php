<div class="d-flex flex-column justify-content-center align-items-center" style="min-height: 60vh;">
    <div class="text-center">
        <div class="bg-warning bg-opacity-10 rounded-circle d-inline-flex p-4 mb-4">
            <i class="bi bi-hourglass-split text-warning" style="font-size: 4rem;"></i>
        </div>
        <h2 class="fw-bold text-warning mb-3">Coming Soon</h2>
        <p class="text-muted fs-5 mb-4">
            Fitur Seleksi & Penilaian sedang dalam pengembangan.<br>
            Silakan tunggu pembaruan berikutnya.
        </p>
        <div class="d-flex gap-3 justify-content-center">
            <a href="<?= APP_URL ?>/admin/dashboard" class="btn btn-primary">
                <i class="bi bi-house me-2"></i>Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>