-- Add foto_profil column to users table
ALTER TABLE users ADD COLUMN foto_profil VARCHAR(255) DEFAULT NULL;
